﻿using System;

namespace LimbajeProiect
{
    class Program
    {
        static void Main(string[] args)
        {

            ParserClass parser = new ParserClass();
            

            
           
        }
    }
}
